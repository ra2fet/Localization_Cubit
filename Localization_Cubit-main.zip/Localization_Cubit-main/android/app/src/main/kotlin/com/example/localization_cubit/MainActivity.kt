package com.example.localization_cubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
