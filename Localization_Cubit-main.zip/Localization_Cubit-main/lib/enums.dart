enum LanguagesTypesEnums {
  initial,
  arabic,
  english,
}