# 🏵 Localizations Cubit

- Simple UI Screen 👍

## 🚀 Getting Started

- This project is a starting point for a Flutter application.

## 💾 Credits

- This repository is to Reduce time & for learning purposes, following of [Flutter Docs]([https://twitter.com/hnasr](https://docs.flutter.dev/ui/accessibility-and-internationalization/internationalization)https://docs.flutter.dev/ui/accessibility-and-internationalization/internationalization).

## 📱 UI

<p align="center">
  <img src="https://github.com/Shalaby-VBS/Localization_Cubit/assets/149938388/0c8bb7fe-1b29-40a3-b1b6-01e72cb06537"/>

## 🛠 Dependencies

1️⃣ shared_preferences:

2️⃣ flutter_bloc:

3️⃣ flutter_localizations:
